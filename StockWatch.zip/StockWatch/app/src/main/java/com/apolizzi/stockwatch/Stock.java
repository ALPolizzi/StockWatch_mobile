package com.apolizzi.stockwatch;

import android.widget.TextView;

public class Stock {
    private String symbol;
    private String name;
    private double delta;
    private double deltaPercent;
    private double price;

    Stock(){
        symbol="";
        name = "";
        delta = 0;
        deltaPercent = 0;
        price = 0;
    }
    Stock(String s, String n, double d, double dp, double p){
        symbol=s;
        name = n;
        delta = d;
        deltaPercent = dp;
        price = p;
    }
    Stock(String s, String n){
        symbol=s;
        name = n;
        delta = 0;
        deltaPercent = 0;
        price = 0;
    }
    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getDelta() {
        return delta;
    }

    public void setDelta(double delta) {
        this.delta = delta;
    }

    public double getDeltaPercent() {
        return deltaPercent;
    }

    public void setDeltaPercent(double deltaPercent) {
        this.deltaPercent = deltaPercent;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
