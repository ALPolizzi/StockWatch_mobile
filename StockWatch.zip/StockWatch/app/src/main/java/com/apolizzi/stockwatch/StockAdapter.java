package com.apolizzi.stockwatch;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Locale;

public class StockAdapter extends RecyclerView.Adapter {
    private static final String TAG = "EmployeesAdapter";
    private List<Stock> stocks;
    private MainActivity mainAct;

    StockAdapter(List<Stock> stocks, MainActivity ma) {
        this.stocks = stocks;
        mainAct = ma;
    }
    public void removeStock(int p){
        notifyItemRemoved(p);
        notifyItemRangeChanged(p, MainActivity.getStockList().size());
    }
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.stock_list_row, parent, false);

        itemView.setOnClickListener(mainAct);
        itemView.setOnLongClickListener(mainAct);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        Stock stock = stocks.get(position);
        ((MyViewHolder) holder).symbol.setText(stock.getSymbol());
        ((MyViewHolder) holder).price.setText(String.valueOf(stock.getPrice()));
        ((MyViewHolder) holder).name.setText(stock.getName());
        ((MyViewHolder) holder).delta.setText(String.valueOf(stock.getDelta()));
        ((MyViewHolder) holder).deltaPercent.setText(String.valueOf(stock.getDeltaPercent()));

        if(stock.getDelta()>0){
            ((MyViewHolder) holder).symbol.setTextColor(Color.GREEN);
            ((MyViewHolder) holder).price.setTextColor(Color.GREEN);
            ((MyViewHolder) holder).name.setTextColor(Color.GREEN);
            ((MyViewHolder) holder).delta.setTextColor(Color.GREEN);
            ((MyViewHolder) holder).deltaPercent.setTextColor(Color.GREEN);
        }if(stock.getDelta()<0){
            ((MyViewHolder) holder).symbol.setTextColor(Color.RED);
            ((MyViewHolder) holder).price.setTextColor(Color.RED);
            ((MyViewHolder) holder).name.setTextColor(Color.RED);
            ((MyViewHolder) holder).delta.setTextColor(Color.RED);
            ((MyViewHolder) holder).deltaPercent.setTextColor(Color.RED);
        }

    }



    @Override
    public int getItemCount() {
        return stocks.size();
    }
}
