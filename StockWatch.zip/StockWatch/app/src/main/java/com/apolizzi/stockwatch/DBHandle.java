
package com.apolizzi.stockwatch;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class DBHandle extends SQLiteOpenHelper {

    private static final String TAG = "DatabaseHandler";

    // If you change the database schema, you must increment the database version.
    private static final int DATABASE_VERSION = 1;

    // DB Name
    private static final String DATABASE_NAME = "StockDB";

    // DB Table Name
    private static final String TABLE_NAME = "StockTable";

    ///DB Columns
    private static final String NAME = "CompanyName";
    private static final String SYMBOL = "StockSymbol";
    private static final String PRICE = "StockPrice";
    private static final String DELTA = "PriceChange";
    private static final String DELTAPERCENT = "PriceChangePercentage";

    // DB Table Create Code
    private static final String SQL_CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    NAME + " TEXT not null unique," +
                    SYMBOL + " TEXT not null unique, " +
                    PRICE + " FLOAT not null, " +
                    DELTA + " FLOAT not null, " +
                    DELTAPERCENT + " FLOAT not null)";

    private SQLiteDatabase database;


    DBHandle(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        database = getWritableDatabase();

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // onCreate is only called is the DB does not exist
        Log.d(TAG, "onCreate: Making New DB");
        db.execSQL(SQL_CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    public ArrayList<Stock> loadStocks() {

        // Load countries - return ArrayList of loaded countries
        Log.d(TAG, "loadCountries: START");
        ArrayList<Stock> stocksList = new ArrayList<>();

        Cursor cursor = database.query(
                TABLE_NAME,  // The table to query
                new String[]{NAME, SYMBOL, PRICE, DELTA, DELTAPERCENT}, // The columns to return
                null, // The columns for the WHERE clause
                null, // The values for the WHERE clause
                null, // don't group the rows
                null, // don't filter by row groups
                null); // The sort order

        if (cursor != null) {
            cursor.moveToFirst();

            for (int i = 0; i < cursor.getCount(); i++) {
                String name = cursor.getString(0);
                String symbol = cursor.getString(1);
                double price = cursor.getFloat(2);
                double delta = cursor.getFloat(3);
                double deltaPercent = cursor.getFloat(4);
                Stock c = new Stock(name, symbol, price, delta, deltaPercent);
                stocksList.add(c);
                cursor.moveToNext();
            }
            cursor.close();
        }
        Log.d(TAG, "loadStocks: DONE");

        return stocksList;
    }



    void addStock(Stock stock) {
        ContentValues values = new ContentValues();

        values.put(NAME, stock.getName());
        values.put(SYMBOL, stock.getSymbol());
        values.put(PRICE, stock.getPrice());
        values.put(DELTA, stock.getDelta());
        values.put(DELTAPERCENT, stock.getDeltaPercent());

        long key = database.insert(TABLE_NAME, null, values);
        Log.d(TAG, "addStock: " + key);
    }

    void updateStock(Stock stock) {
        ContentValues values = new ContentValues();

        values.put(NAME, stock.getName());
        values.put(SYMBOL, stock.getSymbol());
        values.put(PRICE, stock.getPrice());
        values.put(DELTA, stock.getDelta());
        values.put(DELTAPERCENT, stock.getDeltaPercent());

        long numRows = database.update(TABLE_NAME, values, NAME + " = ?", new String[]{stock.getName()});

        Log.d(TAG, "updateSTock: " + numRows);
    }

    void deleteStock(String name) {
        Log.d(TAG, "deleteStock: " + name);

        int cnt = database.delete(TABLE_NAME, NAME + " = ?", new String[]{name});

        Log.d(TAG, "deleteStock: " + cnt);
    }

    void dumpDbToLog() {
        Cursor cursor = database.rawQuery("select * from " + TABLE_NAME, null);
        if (cursor != null) {
            cursor.moveToFirst();

            Log.d(TAG, "dumpDbToLog: vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv");
            for (int i = 0; i < cursor.getCount(); i++) {
                String country = cursor.getString(0);
                String region = cursor.getString(1);
                String subRegion = cursor.getString(2);
                String capital = cursor.getString(3);
                int population = cursor.getInt(4);
                Log.d(TAG, "dumpDbToLog: " +
                        String.format("%s %-18s", NAME + ":", country) +
                        String.format("%s %-18s", SYMBOL + ":", region) +
                        String.format("%s %-18s", PRICE + ":", subRegion) +
                        String.format("%s %-18s", DELTA + ":", capital) +
                        String.format("%s %-18s", DELTAPERCENT + ":", population));
                cursor.moveToNext();
            }
            cursor.close();
        }

        Log.d(TAG, "dumpDbToLog: ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
    }

    void shutDown() {
        database.close();
    }
}
