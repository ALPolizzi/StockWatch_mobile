package com.apolizzi.stockwatch;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.BreakIterator;

public class MyViewHolder extends RecyclerView.ViewHolder {

    public TextView symbol;
    public TextView name;
    public TextView delta;
    public TextView deltaPercent;
    public TextView price;






    MyViewHolder(View view) {
        super(view);
        name = view.findViewById(R.id.stockName);
        symbol = view.findViewById(R.id.stockSymbol);
        delta = view.findViewById(R.id.delta);
        deltaPercent = view.findViewById(R.id.deltaPercent);
        price = view.findViewById(R.id.price);
    }
}
