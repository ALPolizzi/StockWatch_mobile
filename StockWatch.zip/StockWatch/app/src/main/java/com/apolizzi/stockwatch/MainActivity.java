package com.apolizzi.stockwatch;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener, View.OnLongClickListener {


    private static final String TAG = "Main Activity";
    private static List<Stock> stocks = new ArrayList<>();
    private RecyclerView recyclerView;
    private SwipeRefreshLayout swiper;
    private StockAdapter mAdapter;
    private DBHandle databaseHandler;
    private ArrayList<Stock> tStocks;
    private HashMap<String, String> stockMap = new HashMap<>();
    private HashMap<String, Stock> stockObjMap = new HashMap<>();
    private MainActivity mainActivityInstance;

    public static List<Stock> getStockList() {
        return stocks;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
                .permitAll().build();
        StrictMode.setThreadPolicy(policy);

        mainActivityInstance = this;
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recycler);

        mAdapter = new StockAdapter(stocks, this);

        recyclerView.setAdapter(mAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        swiper = findViewById(R.id.swiper);

        swiper.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                doRefresh();
            }
        });

        databaseHandler = new DBHandle(this);


        //Execute Name Downloader
        new StockLoaderRunnable(this).run();

        //load stocks from DB into temp list
        tStocks = databaseHandler.loadStocks();
        //ArrayList<Stock> sList = new ArrayList<>();

        //ExecutorService executorService = Executors.newSingleThreadExecutor();
        if(isConnected()){
            for(Stock s: tStocks){
                new StockDataLoader(this, s.getSymbol()).run();
            }
        }
        else{
            DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                    stocks=new ArrayList<>();
                    for( Stock s : tStocks ){//put stocks from DB's tStock list into stocks list 0'd out
                        stocks.add(new Stock(s.getSymbol(),s.getName(), 0,0,0));
                    }
                }
            };

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("You are offline").setPositiveButton("Okay", dialogClickListener).show();
            //sort the list
            class LexicographicComparator implements Comparator<Stock> {
                @Override
                public int compare(Stock a, Stock b) {
                    return a.getSymbol().compareToIgnoreCase(b.getSymbol());
                }
            }
            Collections.sort(stocks, new LexicographicComparator());
            //notify adapter
            mAdapter.notifyDataSetChanged();

        }

    }


    public boolean isConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        if (cm == null) {
            Toast.makeText(this, "Cannot access ConnectivityManager", Toast.LENGTH_SHORT).show();
            return false;
        }

        NetworkInfo netInfo = cm.getActiveNetworkInfo();

        if (netInfo != null && netInfo.isConnected()) {

        return true;
        } else {//!connected
        return false;
        }
    }

    @Override
    protected void onResume() {
        databaseHandler.dumpDbToLog();
        ArrayList<Stock> list = databaseHandler.loadStocks();

        stocks.clear();
        stocks.addAll(list);
        stockObjMap.clear();
        for(Stock s: stocks)
            stockObjMap.put(s.getSymbol(),s);
        mAdapter.notifyDataSetChanged();

        super.onResume();
    }

    @Override
    protected void onDestroy() {
        databaseHandler.shutDown();
        super.onDestroy();
    }

    private void doRefresh() {
        ArrayList<Stock> tStocks = databaseHandler.loadStocks();
        if(isConnected()){
            for(Stock s: tStocks){
                new StockDataLoader(this, s.getSymbol()).run();
            }
        } else {
            DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    //exit dialog
                }
            };

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("You are offline").setPositiveButton("Okay", dialogClickListener).show();
        }
        mAdapter.notifyDataSetChanged();
        swiper.setRefreshing(false);
    }

    @Override
    public void onClick(View v) {
        //open website for stock
        String url = "https://www.marketwatch.com/investing/stock/" + stocks.get(recyclerView.getChildLayoutPosition(v)).getSymbol();
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        startActivity(i);
    }

    @Override
    public boolean onLongClick(View v) {


        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which){
                    case DialogInterface.BUTTON_POSITIVE:
                        //delete stock

                        int p=recyclerView.getChildLayoutPosition(v);
                        stocks.remove(p);
                        mAdapter.removeStock(p);
                        dialog.dismiss();
                        break;

                    case DialogInterface.BUTTON_NEGATIVE:
                        dialog.dismiss();
                        break;
                }
            }
        };

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you want to delete?")
                .setPositiveButton("Delete Stock", dialogClickListener)
                .setNegativeButton("Cancel", dialogClickListener)
                .show();
        return false;
    }

    public void downloadFailed() {
    }

    public void updateData1(ArrayList<Stock> stockList) {
        Log.d(TAG, "updateData1: Adding Symbols to stockMap");
            for(Stock s: stockList) {
                stockMap.put( s.getName(),s.getSymbol());
            }
        Log.d(TAG, "updateData1: "+stockMap.get("ROAD"));
        Log.d(TAG, stockMap.toString());
    }

    public void updateData2(Stock stock) {


            //databaseHandler.deleteStock(s.getName());
            //databaseHandler.updateStock(s); /* ? */
            //update list
           // stocks = databaseHandler.loadStocks();
            if(!stockObjMap.containsKey(stock.getSymbol())) {
                Log.d(TAG, "updateData2: Adding stock" + stock.getSymbol() + "to list");
                stocks.add(stock);
                stockObjMap.put(stock.getSymbol(),stock);
                //sort stocks
                class LexicographicComparator implements Comparator<Stock> {
                    @Override
                    public int compare(Stock a, Stock b) {
                        return a.getSymbol().compareToIgnoreCase(b.getSymbol());
                    }
                }
                Collections.sort(stocks, new LexicographicComparator());
                mAdapter.notifyDataSetChanged();
            }
    }

    // create an action bar button
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // R.menu.mymenu is a reference to an xml file named mymenu.xml which should be inside your res/menu directory.
        // If you don't have res/menu, just create a directory named "menu" inside res
        getMenuInflater().inflate(R.menu.toolbar, menu);
        return super.onCreateOptionsMenu(menu);
    }

    // handle button activities
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.mybutton) {
            // Add new stock
            if(isConnected()){
                LayoutInflater inflater = this.getLayoutInflater();
                View view= inflater.inflate(R.layout.dialog_newstock, null);
                DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which){
                            case DialogInterface.BUTTON_POSITIVE:
                                //symbol of stock user wants to add:
                                String sym = ((EditText)view.findViewById(R.id.editSymbol)).getText().toString();
                                if(stockMap.containsKey(sym.toUpperCase())){
                                    //launch data downloader and add stock to list
                                    new StockDataLoader(mainActivityInstance,sym).run();
                                } else{
                                    //not in list, error
                                    notInList();
                                }
                                break;

                            case DialogInterface.BUTTON_NEGATIVE:
                                //No button clicked, nothing to do here
                                dialog.dismiss();
                                break;
                        }
                    }
                };

                AlertDialog.Builder builder = new AlertDialog.Builder(this);

                builder .setView(view)
                        .setPositiveButton("Add Stock", dialogClickListener)
                        .setNegativeButton("Cancel", dialogClickListener).show();


            } else {//offline
                DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //exit dialog
                    }
                };

                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage("You are offline").setPositiveButton("Okay", dialogClickListener).show();

            }//end offline block
        }
        return super.onOptionsItemSelected(item);
    }

    private void notInList() {
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        };
        new AlertDialog.Builder(this).setMessage("Stock Not Found").setPositiveButton("Okay", dialogClickListener).show();
    }
}